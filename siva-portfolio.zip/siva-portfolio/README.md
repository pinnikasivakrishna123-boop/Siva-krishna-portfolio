# Siva Krishna Pinnika — Portfolio Website

A responsive, single-page portfolio for an Artificial Intelligence and Data Science student.

## Run locally
1. Extract `siva-portfolio.zip`.
2. Open `index.html` in a modern browser.

No build tools or dependencies are required.

## Customize before publishing
- Add your real project repository/demo links and screenshots.
- Add verified tools/libraries you have used (for example, only if applicable).
- Add graduation year, experience, certifications, or a resume link if you want.
- Check that the university name and degree wording match your official records.

## Publish
You can deploy the folder with any static website host. Upload `index.html` as the site entry point.
